public class Trabalho12 {
    public static void main(String[] args) {
        int i,valor;
        for (i=0;i<=10;i++) {
            valor= 7*i;
            System.out.println("7x"+i+"="+valor);
        }
    }
}
