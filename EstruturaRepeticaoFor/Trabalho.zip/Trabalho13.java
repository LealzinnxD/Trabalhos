public class Trabalho13 {
    public static void main(String[] args) {
        int soma,i;
        for (i=1;i<=100;i++) {
            soma=i+i;
            System.out.println("Resultado das somas de suas variantes: " + soma);
        }
    }
}
